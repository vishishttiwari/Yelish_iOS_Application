//
//  GradientView1.h
//  Yelish
//
//  Created by Vishisht Mani Tiwari on 24/01/16.
//  Copyright © 2016 Vishisht Mani Tiwari. All rights reserved.
//

#import <UIKit/UIKit.h>

IB_DESIGNABLE
@interface GradientView1 : UIView

@end
