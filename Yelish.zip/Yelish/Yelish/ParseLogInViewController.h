//
//  ParseLogInViewController.h
//  Yelish
//
//  Created by Vishisht Mani Tiwari on 22/01/16.
//  Copyright © 2016 Vishisht Mani Tiwari. All rights reserved.
//

#import <ParseUI/ParseUI.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

@interface ParseLogInViewController : PFLogInViewController

@end
