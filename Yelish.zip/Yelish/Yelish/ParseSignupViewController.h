//
//  ParseSignupViewController.h
//  Yelish
//
//  Created by Vishisht Mani Tiwari on 23/01/16.
//  Copyright © 2016 Vishisht Mani Tiwari. All rights reserved.
//

#import <ParseUI/ParseUI.h>

@interface ParseSignupViewController : PFSignUpViewController

@end
