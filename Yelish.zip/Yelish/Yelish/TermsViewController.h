//
//  TermsViewController.h
//  Yelish
//
//  Created by Vishisht Mani Tiwari on 02/02/16.
//  Copyright © 2016 Vishisht Mani Tiwari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TermsViewController : UIViewController

@property (strong, nonatomic) IBOutlet UILabel *text;

@end
