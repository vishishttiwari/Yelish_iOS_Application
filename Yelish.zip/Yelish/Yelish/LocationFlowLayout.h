//
//  LocationFlowLayout.h
//  Yelish
//
//  Created by Vishisht Mani Tiwari on 10/01/16.
//  Copyright © 2016 Vishisht Mani Tiwari. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationFlowLayout : UICollectionViewFlowLayout

@end
